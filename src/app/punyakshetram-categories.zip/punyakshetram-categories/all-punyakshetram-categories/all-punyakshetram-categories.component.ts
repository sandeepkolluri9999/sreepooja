import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-punyakshetram-categories',
  templateUrl: './all-punyakshetram-categories.component.html',
  styleUrls: ['./all-punyakshetram-categories.component.css']
})
export class AllPunyakshetramCategoriesComponent implements OnInit {

  constructor() { }
  ngOnInit(){
    
  }
}
