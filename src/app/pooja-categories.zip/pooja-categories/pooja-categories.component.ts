import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-categories',
  templateUrl: './pooja-categories.component.html',
  styleUrls: ['./pooja-categories.component.css']
})
export class PoojaCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
