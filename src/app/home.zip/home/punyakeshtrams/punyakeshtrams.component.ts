import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-punyakeshtrams',
  templateUrl: './punyakeshtrams.component.html',
  styleUrls: ['./punyakeshtrams.component.css']
})
export class PunyakeshtramsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
