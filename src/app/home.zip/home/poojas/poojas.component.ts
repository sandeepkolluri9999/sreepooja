import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poojas',
  templateUrl: './poojas.component.html',
  styleUrls: ['./poojas.component.css']
})
export class PoojasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
