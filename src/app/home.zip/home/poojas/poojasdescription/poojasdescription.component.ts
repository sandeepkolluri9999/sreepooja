import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poojasdescription',
  templateUrl: './poojasdescription.component.html',
  styleUrls: ['./poojasdescription.component.css']
})
export class PoojasdescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
