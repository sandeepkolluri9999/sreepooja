import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-poojasiteam',
  templateUrl: './poojasiteam.component.html',
  styleUrls: ['./poojasiteam.component.css']
})
export class PoojasiteamComponent  {

  constructor() { }
@Input() item;


}
