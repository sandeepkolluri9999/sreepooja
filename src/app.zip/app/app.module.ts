import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { FormsModule }   from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { PoojasComponent } from './home/poojas/poojas.component';
import { PoojasdescriptionComponent } from './home/poojas/poojasdescription/poojasdescription.component';
import { PoojasiteamsComponent } from './home/poojas/poojasiteams/poojasiteams.component';
import { PoojasiteamComponent } from './home/poojas/poojasiteams/poojasiteam/poojasiteam.component';
import { PunyakeshtramsComponent } from './home/punyakeshtrams/punyakeshtrams.component';
import { PunyakeshtramdescriptionComponent } from './home/punyakeshtrams/punyakeshtramdescription/punyakeshtramdescription.component';
import { PunyakeshtramiteamsComponent } from './home/punyakeshtrams/punyakeshtramiteams/punyakeshtramiteams.component';
import { PunyakeshtramiteamComponent } from './home/punyakeshtrams/punyakeshtramiteams/punyakeshtramiteam/punyakeshtramiteam.component';
import { HomeComponent } from './home/home.component';
import { ImageComponent } from './login/image/image.component';
import { LoginFormComponent } from './login/login-form/login-form.component';
import { RegisterFormComponent } from './register/register-form/register-form.component';
import { RegisterAsAPurohitComponent } from './register-as-a-purohit/register-as-a-purohit.component';

import { TopHeaderComponent } from './top-header/top-header.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdateProfileComponent } from './profile/update-profile/update-profile.component';
import { MyOrderComponent } from './profile/my-order/my-order.component';
import { ChangePasswordComponent } from './profile/change-password/change-password.component';
import { HeaderTopComponent } from './header-top/header-top.component';
import { Footer2Component } from './footer2/footer2.component';
import { SliderComponent } from './home/slider/slider.component';
import { PoojaCategoriesComponent } from './pooja-categories/pooja-categories.component';
import { AllPoojaCategoriesComponent } from './pooja-categories/all-pooja-categories/all-pooja-categories.component';
import { AllPoojaCategoryItemsComponent } from './pooja-categories/all-pooja-categories/all-pooja-category-items/all-pooja-category-items.component';
import { AllPoojaCategoryItemComponent } from './pooja-categories/all-pooja-categories/all-pooja-category-items/all-pooja-category-item/all-pooja-category-item.component';
import { FestivalPoojaItemsComponent } from './pooja-categories/all-pooja-categories/festival-pooja-items/festival-pooja-items.component';
import { FestivalPoojaItemComponent } from './pooja-categories/all-pooja-categories/festival-pooja-items/festival-pooja-item/festival-pooja-item.component';
import { LifeStepsItemsComponent } from './pooja-categories/all-pooja-categories/life-steps-items/life-steps-items.component';
import { LifeStepsItemComponent } from './pooja-categories/all-pooja-categories/life-steps-items/life-steps-item/life-steps-item.component';
import { OccasionalPoojaItemsComponent } from './pooja-categories/all-pooja-categories/occasional-pooja-items/occasional-pooja-items.component';
import { OccasionalPoojaItemComponent } from './pooja-categories/all-pooja-categories/occasional-pooja-items/occasional-pooja-item/occasional-pooja-item.component';
import { SpecialPoojaItemsComponent } from './pooja-categories/all-pooja-categories/special-pooja-items/special-pooja-items.component';
import { SpecialPoojaItemComponent } from './pooja-categories/all-pooja-categories/special-pooja-items/special-pooja-item/special-pooja-item.component';
import { PunyakshetramCategoriesComponent } from './punyakshetram-categories/punyakshetram-categories.component';
import { AllPunyakshetramCategoriesComponent } from './punyakshetram-categories/all-punyakshetram-categories/all-punyakshetram-categories.component';
import { AllPunyakshetramCategoryItemsComponent } from './punyakshetram-categories/all-punyakshetram-categories/all-punyakshetram-category-items/all-punyakshetram-category-items.component';
import { AllPunyakshetramCategoryItemComponent } from './punyakshetram-categories/all-punyakshetram-categories/all-punyakshetram-category-items/all-punyakshetram-category-item/all-punyakshetram-category-item.component';
import { RiverItemsComponent } from './punyakshetram-categories/all-punyakshetram-categories/river-items/river-items.component';
import { RiverItemComponent } from './punyakshetram-categories/all-punyakshetram-categories/river-items/river-item/river-item.component';
import { ShaktipeetamsItemsComponent } from './punyakshetram-categories/all-punyakshetram-categories/shaktipeetams-items/shaktipeetams-items.component';
import { ShaktipeetamItemComponent } from './punyakshetram-categories/all-punyakshetram-categories/shaktipeetams-items/shaktipeetam-item/shaktipeetam-item.component';



const approot: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},  
  {path:'apppoojs',component:AllPoojaCategoriesComponent},
  {path:'festivalpoojas',component:FestivalPoojaItemsComponent},
  {path:'LifeStepsI',component:LifeStepsItemsComponent},
  {path:'OccasionalPooja',component:OccasionalPoojaItemsComponent},
  {path:'SpecialPooja',component:SpecialPoojaItemsComponent},
  {path:'allpunyakshetrams',component:AllPunyakshetramCategoryItemsComponent},
  {path:'riverpunyakshetrams',component:RiverItemsComponent},
  {path:'shaktipeetamsPunyakshetrams',component:ShaktipeetamsItemsComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
   
    PoojasComponent,
    PoojasdescriptionComponent,
    PoojasiteamsComponent,
    PoojasiteamComponent,
    PunyakeshtramsComponent,
    PunyakeshtramdescriptionComponent,
    PunyakeshtramiteamComponent,
    PunyakeshtramiteamsComponent,
    
    HomeComponent,
    ImageComponent,
    LoginFormComponent,
    RegisterFormComponent,
    RegisterAsAPurohitComponent,
  
    TopHeaderComponent,
    ProfileComponent,
    UpdateProfileComponent,
    MyOrderComponent,
    ChangePasswordComponent,
    HeaderTopComponent,
    Footer2Component,
    SliderComponent,
    PoojaCategoriesComponent,
    AllPoojaCategoriesComponent,
    AllPoojaCategoryItemsComponent,
    AllPoojaCategoryItemComponent,
    FestivalPoojaItemsComponent,
    FestivalPoojaItemComponent,
    LifeStepsItemsComponent,
    LifeStepsItemComponent,
    OccasionalPoojaItemsComponent,
    OccasionalPoojaItemComponent,
    SpecialPoojaItemsComponent,
    SpecialPoojaItemComponent,
    PunyakshetramCategoriesComponent,
    AllPunyakshetramCategoriesComponent,
    AllPunyakshetramCategoryItemsComponent,
    AllPunyakshetramCategoryItemComponent,
    RiverItemsComponent,
    RiverItemComponent,
    ShaktipeetamsItemsComponent,
    ShaktipeetamItemComponent
 
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(approot, {useHash:true})
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

