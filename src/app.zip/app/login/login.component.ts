import { Component, OnInit } from '@angular/core';
import {UserserviceService}from '../userservice.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userservice:UserserviceService ) { }

  ngOnInit() {
  }
  loginupdate(){
    this.userservice.updateuservalid(true);
  }

}
