import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-as-a-purohit',
  templateUrl: './register-as-a-purohit.component.html',
  styleUrls: ['./register-as-a-purohit.component.css']
})
export class RegisterAsAPurohitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
