import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
mysubobs=new BehaviorSubject(false);
updateuservalid(data){
  this.mysubobs.next(data);
}
}
