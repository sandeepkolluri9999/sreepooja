import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-punyakeshtramdescription',
  templateUrl: './punyakeshtramdescription.component.html',
  styleUrls: ['./punyakeshtramdescription.component.css']
})
export class PunyakeshtramdescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
