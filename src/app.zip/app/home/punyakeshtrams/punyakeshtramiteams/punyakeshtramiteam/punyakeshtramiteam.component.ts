import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-punyakeshtramiteam',
  templateUrl: './punyakeshtramiteam.component.html',
  styleUrls: ['./punyakeshtramiteam.component.css']
})
export class PunyakeshtramiteamComponent  {


  @Input() item;

}
