import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-punyakshetram-categories',
  templateUrl: './punyakshetram-categories.component.html',
  styleUrls: ['./punyakshetram-categories.component.css']
})
export class PunyakshetramCategoriesComponent implements OnInit {

  constructor() { }
  

  ngOnInit() {
   
  }
}
